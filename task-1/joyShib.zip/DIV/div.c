#include<stdio.h>
int main(){
    int id;
    scanf("%d",&id);
    int div = id/2;
    printf("%d",div);
}