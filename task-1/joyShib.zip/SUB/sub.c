#include<stdio.h>
int main(){
    int id;
    scanf("%d",&id);
    int sub = id-2;
    printf("%d",sub);
}