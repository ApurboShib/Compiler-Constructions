#include<stdio.h>
int main(){
    int id;
    scanf("%d",&id);
    int add = id+2;
    printf("%d",add);
}